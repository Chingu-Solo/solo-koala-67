$(document).ready(function(){

// Scroll 
$(window).scroll(function() {    
    var scroll = $(window).scrollTop();

     //>=, not <=
    if (scroll >= 100) {
        //clearHeader, not clearheader - caps H
        $(".mid-section-header").addClass("fixed-header");
    }else
	{
	   $(".mid-section-header").removeClass("fixed-header");
	}
}); //missing );


})